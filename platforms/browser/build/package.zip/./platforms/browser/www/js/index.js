document.addEventListener("deviceready", function(){
   AppInit.init();
});
